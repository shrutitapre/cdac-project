package com.app.utils;

public interface OrderUtil {
	String ACTIVE = "ACTIVE";
	String CANCELLED = "CANCELLED";
	String OLD = "OLD";
	String SUCCESS = "SUCCESS";
	String FAIL = "FAIL";
}
