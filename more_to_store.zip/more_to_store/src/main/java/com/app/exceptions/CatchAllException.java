package com.app.exceptions;

@SuppressWarnings("serial")
public class CatchAllException extends RuntimeException {

}
