package com.app.exceptions;

@SuppressWarnings("serial")
public class AdminControllerException extends RuntimeException {

}
