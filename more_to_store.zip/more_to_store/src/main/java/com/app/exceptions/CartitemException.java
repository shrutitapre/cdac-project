package com.app.exceptions;

@SuppressWarnings("serial")
public class CartitemException extends RuntimeException {
	public CartitemException() {
		// TODO Auto-generated constructor stub
	}

	public CartitemException(String msg) {
		super(msg);
	}

}
