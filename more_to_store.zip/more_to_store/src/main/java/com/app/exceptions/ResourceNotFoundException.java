package com.app.exceptions;

@SuppressWarnings("serial")
public class ResourceNotFoundException extends RuntimeException {

}
