package com.app.exceptions;

@SuppressWarnings("serial")
public class CustomerException extends RuntimeException {

}
