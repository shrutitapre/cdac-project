package com.app.exceptions;

@SuppressWarnings("serial")
public class WishlistException extends RuntimeException {
public WishlistException() {
	// TODO Auto-generated constructor stub
}
public WishlistException(String msg) {
	super(msg);
}
}
