package com.app.dao;

public interface ICartDao {

}
