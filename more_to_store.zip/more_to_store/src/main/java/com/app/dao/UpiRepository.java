package com.app.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.app.pojos.Upi;

public interface UpiRepository extends JpaRepository<Upi, Long> {

}
