package com.app.pojos;

public enum SupportedPaymentModesEnum {
	CARD, UPI, NETBANKING, COD
}
